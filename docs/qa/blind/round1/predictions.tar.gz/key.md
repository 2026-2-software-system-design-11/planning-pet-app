# 블라인드 그림 열쇠

예측자에게 주지 않는다. 그림 번호와 부품을 잇는다.

## screen-01.png 홈

| 번호 | 부품 |
|---|---|
| 1 | JButton "출석 +20P" |
| 2 | JToggleButton "홈" |
| 3 | JToggleButton "일정관리" |
| 4 | JToggleButton "pet" |
| 5 | JToggleButton "통계" 비활성 |
| 6 | JToggleButton "설정" |
| 7 | JButton "<" |
| 8 | JButton ">" |
| 9 | JLabel "1" |
| 10 | JLabel "10 빨래" |
| 11 | JLabel "10:00~11:00" (마우스를 올리면 설명) |
| 12 | JCheckBox "" |
| 13 | JLabel "알고리즘 과제 2번" |
| 14 | JButton "수정" |
| 15 | JButton "삭제" |
| 16 | JLabel "자소서 초안 메모" (마우스를 올리면 설명) |
| 17 | JLabel "시간 정하기" (마우스를 올리면 설명) |
| 18 | JTextField "" |
| 19 | JButton "일정 추가" |

## screen-02.png 일정관리

| 번호 | 부품 |
|---|---|
| 1 | JButton "출석 +20P" |
| 2 | JToggleButton "홈" |
| 3 | JToggleButton "일정관리" |
| 4 | JToggleButton "pet" |
| 5 | JToggleButton "통계" 비활성 |
| 6 | JToggleButton "설정" |
| 7 | JButton "<" |
| 8 | JButton ">" |
| 9 | JButton "오늘" |
| 10 | JButton "자동 배치" |
| 11 | JButton "일정 추가" |
| 12 | 시간표 블록의 체크박스 (고정 일정, 자료구조) |
| 13 | 시간표 블록의 체크박스 (할 일, 끝냄, 토익 스터디) |
| 14 | 시간표 블록의 체크박스 (할 일, 자소서 초안) |
| 15 | 시간표 블록 (고정 일정, 자료구조) |
| 16 | 시간표 블록 (할 일, 끝냄, 토익 스터디) |
| 17 | 시간표 블록 (할 일, 자소서 초안) |
| 18 | 시간표의 빈 칸 |
| 19 | JCheckBox "" |
| 20 | JLabel "11/10 빨래" |
| 21 | JButton "수정" |
| 22 | JButton "삭제" |

## screen-03.png pet

| 번호 | 부품 |
|---|---|
| 1 | JButton "출석 +20P" |
| 2 | JToggleButton "홈" |
| 3 | JToggleButton "일정관리" |
| 4 | JToggleButton "pet" |
| 5 | JToggleButton "통계" 비활성 |
| 6 | JToggleButton "설정" |
| 7 | JToggleButton "쿠션 ✓" |
| 8 | JToggleButton "화분 ✓" |
| 9 | JToggleButton "러그" |
| 10 | JButton "상점" |

## screen-04.png 설정

| 번호 | 부품 |
|---|---|
| 1 | JButton "출석 +20P" |
| 2 | JToggleButton "홈" |
| 3 | JToggleButton "일정관리" |
| 4 | JToggleButton "pet" |
| 5 | JToggleButton "통계" 비활성 |
| 6 | JToggleButton "설정" |
| 7 | JCheckBox "컴퓨터 켤 때 같이 실행" 비활성 |
| 8 | JButton "폴더 열기" 비활성 |

## screen-05.png 일정 입력 창(추가)

| 번호 | 부품 |
|---|---|
| 1 | JRadioButton "할 일" |
| 2 | JRadioButton "고정 일정" |
| 3 | JTextField "" |
| 4 | JSpinner "" |
| 5 | JCheckBox "정하기" |
| 6 | JSpinner "" 비활성 |
| 7 | JSpinner "" |
| 8 | JCheckBox "매주 반복, 끝" 비활성 |
| 9 | JSpinner "" 비활성 |
| 10 | JTextArea "" |
| 11 | JButton "취소" |
| 12 | JButton "저장" |

## screen-06.png 일정 입력 창(수정)

| 번호 | 부품 |
|---|---|
| 1 | JRadioButton "할 일" 비활성 |
| 2 | JRadioButton "고정 일정" 비활성 |
| 3 | JTextField "" |
| 4 | JSpinner "" |
| 5 | JCheckBox "정하기" |
| 6 | JSpinner "" |
| 7 | JSpinner "" |
| 8 | JCheckBox "매주 반복, 끝" 비활성 |
| 9 | JSpinner "" 비활성 |
| 10 | JTextArea "" |
| 11 | JButton "취소" |
| 12 | JButton "저장" |
| 13 | JButton "삭제" |

## screen-07.png 시각 고치기 창

| 번호 | 부품 |
|---|---|
| 1 | JSpinner "" |
| 2 | JSpinner "" |
| 3 | JButton "시간 빼기" |
| 4 | JButton "취소" |
| 5 | JButton "저장" |

## screen-08.png 자동 배치 결과 창

| 번호 | 부품 |
|---|---|
| 1 | JTable "" |
| 2 | JTableHeader "" |
| 3 | JButton "취소" |
| 4 | JButton "적용" |

## screen-09.png 상점 창

| 번호 | 부품 |
|---|---|
| 1 | JButton "사기" 비활성 |
| 2 | JButton "닫기" |

## screen-10.png 반려동물 고르기 창

| 번호 | 부품 |
|---|---|
| 1 | JRadioButton "고양이" |
| 2 | JRadioButton "강아지" |
| 3 | JTextField "" |
| 4 | JButton "시작하기" |

## screen-11.png 일정 삭제 확인 창(반복 일정)

| 번호 | 부품 |
|---|---|
| 1 | JButton "이 일정만" |
| 2 | JButton "이후 반복 모두" |
| 3 | JButton "취소" |
