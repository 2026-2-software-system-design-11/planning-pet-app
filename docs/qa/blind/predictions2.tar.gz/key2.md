# 블라인드 그림 열쇠 2차

예측자에게 주지 않는다. 그림 번호와 부품을 잇는다.

## screen-12.png 홈, 일정이 하나도 없는 처음

| 번호 | 부품 |
|---|---|
| 1 | JButton "출석 +20P" |
| 2 | JToggleButton "홈" |
| 3 | JToggleButton "일정관리" |
| 4 | JToggleButton "pet" |
| 5 | JToggleButton "통계" 비활성 |
| 6 | JToggleButton "설정" |
| 7 | JButton "<" |
| 8 | JButton ">" |
| 9 | JLabel "1" |
| 10 | JTextField "" |
| 11 | JButton "일정 추가" |

## screen-13.png 일정 입력 창(추가), 저장을 누른 뒤 오류

| 번호 | 부품 |
|---|---|
| 1 | JRadioButton "할 일" |
| 2 | JRadioButton "고정 일정" |
| 3 | JTextField "" |
| 4 | JSpinner "" |
| 5 | JCheckBox "정하기" |
| 6 | JSpinner "" |
| 7 | JSpinner "" |
| 8 | JCheckBox "매주 반복, 끝" 비활성 |
| 9 | JSpinner "" 비활성 |
| 10 | JTextArea "" |
| 11 | JButton "취소" |
| 12 | JButton "저장" |

## screen-14.png 일정 삭제 확인 창(반복 아님)

| 번호 | 부품 |
|---|---|
| 1 | JButton "지우기" |
| 2 | JButton "취소" |

## screen-15.png 일정 입력 창(고정 일정 수정)

| 번호 | 부품 |
|---|---|
| 1 | JRadioButton "할 일" 비활성 |
| 2 | JRadioButton "고정 일정" 비활성 |
| 3 | JTextField "" |
| 4 | JSpinner "" |
| 5 | JCheckBox "정하기" 비활성 |
| 6 | JSpinner "" |
| 7 | JSpinner "" |
| 8 | JCheckBox "매주 반복, 끝" 비활성 |
| 9 | JSpinner "" 비활성 |
| 10 | JTextArea "" |
| 11 | JButton "취소" |
| 12 | JButton "저장" |
| 13 | JButton "삭제" |

## screen-16.png 상점 창(300P, 살 수 있는 것 있음)

| 번호 | 부품 |
|---|---|
| 1 | JButton "사기" 비활성 |
| 2 | JButton "사기" |
| 3 | JButton "닫기" |

## screen-17.png 자동 배치 결과 창(놓지 못한 할 일 있음)

| 번호 | 부품 |
|---|---|
| 1 | JTable "" |
| 2 | JTableHeader "" |
| 3 | JButton "취소" |
| 4 | JButton "적용" |

## screen-18.png 홈, 할 일 줄에서 오른쪽 버튼을 누른 뒤

| 번호 | 부품 |
|---|---|
| 1 | JMenuItem "수정" |
| 2 | JMenuItem "삭제" |

## screen-19.png 시각 고치기 창(시각 없는 할 일)

| 번호 | 부품 |
|---|---|
| 1 | JSpinner "" |
| 2 | JSpinner "" |
| 3 | JButton "취소" |
| 4 | JButton "저장" |
